---
name: 🐞 Bug report
about: Jelents hibát
labels: bug
---

**Leírás**
Mi a hiba?

**Lépések a reprodukcióhoz**
1.
2.

**Várt eredmény**

**Log/konzol**

**Környezet**
- Hálózat:
- Szerződés verzió:
