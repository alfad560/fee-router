---
name: ✨ Feature request
about: Új funkció javaslat
labels: enhancement
---

**Mi a probléma / igény?**

**Javasolt megoldás**

**Alternatívák**

**Egyéb megjegyzés**
