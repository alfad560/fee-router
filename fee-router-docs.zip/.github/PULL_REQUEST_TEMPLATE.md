## Összefoglaló
Röviden mit változtattál és miért?

## Részletek
- 

## Teszt
- 

## Kapcsolódó issue
Closes #...
