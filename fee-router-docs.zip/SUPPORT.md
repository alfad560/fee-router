# SUPPORT.md

Kérdés / hiba esetén:
- GitHub Issues
- Email: support@feerouter.xyz
- Discord: https://discord.gg/feerouter
