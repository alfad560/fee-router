# CODE_OF_CONDUCT.md

A közösségbarát légkör érdekében minden résztvevőnek be kell tartania a tiszteletteljes kommunikáció szabályait.
Bárminemű zaklatás, diszkrimináció nem elfogadható.
